﻿using DamroBackEnd.Service.DTOS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamroBackEnd.Service.Interface
{
    public interface IMenu
    {
        Task<IQueryable<MenuWithStatusDto>?> GetSelectedMenuwithStatusAsync(int userId, CancellationToken cancellationToken);
        Task<IQueryable<MenuGetAllDtos>?> GetAllMenusAsync(CancellationToken cancellationToken);
    }
}
