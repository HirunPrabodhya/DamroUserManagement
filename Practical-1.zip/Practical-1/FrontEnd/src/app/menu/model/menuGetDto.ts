export interface IMenu{
    menuId: number;
    menuName?: string;
    isActive?:string;
}