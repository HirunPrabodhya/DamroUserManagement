export interface IUser{
        userId: number;
        firstName: string;
        middleName: string;
        lastName: string;
}