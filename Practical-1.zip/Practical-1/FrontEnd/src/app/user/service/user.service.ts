import { Injectable, inject } from '@angular/core';
import { BASE_URL } from '../../app.config';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError } from 'rxjs';
import { IUser } from '../model/UserGetDto';
import { CustomeErrorHandler } from '../../helper/handleError';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl:string = inject(BASE_URL);
  private http:HttpClient = inject(HttpClient);

  getUserAll():Observable<IUser[]>{
      return this.http.get<IUser[]>(`${this.baseUrl}/users`)
                      .pipe(
                        catchError(CustomeErrorHandler.handleError)
                      );
  }
}
