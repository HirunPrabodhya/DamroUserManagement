﻿using DamroBackEnd.Data;
using DamroBackEnd.Service.DTOS;
using DamroBackEnd.Service.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamroBackEnd.Service.Implementation
{
    public class UserService : IUser
    {
        private readonly UserPermissionDbContext _context;

        public UserService(UserPermissionDbContext context)
        {
            _context = context;
        }

        public async Task<IQueryable<UserGetAllDto>?> GetAllUsersAsync(CancellationToken cancellationToken)
        {
                    var users = await _context.User.ToListAsync(cancellationToken); 
                if(users.Count == 0)
                         return null;
            var userDtos =  users.Select(x => new UserGetAllDto
            {
                FirstName = x.FirstName,
                MiddleName = x.MiddleName,
                LastName = x.LastName,
                UserId = x.UserId,
            }).AsQueryable();
             
            return userDtos;
        }
    }
}
