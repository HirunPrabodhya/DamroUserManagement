﻿using DamroBackEnd.Service.DTOS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamroBackEnd.Service.Interface
{
    public interface IPermision
    {
        Task<string?> AddPermissionAsync(PermissionGetDto permisstionGetDto, CancellationToken cancellationToken);
    }
}
