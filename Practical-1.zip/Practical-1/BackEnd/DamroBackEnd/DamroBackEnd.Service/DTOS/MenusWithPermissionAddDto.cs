﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamroBackEnd.Service.DTOS
{
    public class MenusWithPermissionAddDto
    {
        public int MenuId { get; set; }
        public string IsActive { get; set; }
    }
}
