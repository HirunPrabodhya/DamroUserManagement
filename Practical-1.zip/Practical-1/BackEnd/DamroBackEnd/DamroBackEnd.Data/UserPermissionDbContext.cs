﻿using DamroBackEnd.Modle;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamroBackEnd.Data
{
    public class UserPermissionDbContext : DbContext
    {
        public DbSet<User> User { get; set; }
        public DbSet<Menu> Menu { get; set; }
        public DbSet<Permission> Permission { get; set; }
        public UserPermissionDbContext(DbContextOptions<UserPermissionDbContext> option) : base(option)
        {
            
        }
    }
}
