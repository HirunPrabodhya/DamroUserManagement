﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamroBackEnd.Modle
{
    public class Permission
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int MenuId { get; set; }
        public string IsActive { get; set; }
        public User? User { get; set; }
        public Menu? Menu { get; set; }
    }
}
