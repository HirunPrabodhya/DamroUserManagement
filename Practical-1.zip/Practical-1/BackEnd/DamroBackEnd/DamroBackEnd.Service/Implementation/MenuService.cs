﻿using DamroBackEnd.Data;
using DamroBackEnd.Service.DTOS;
using DamroBackEnd.Service.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamroBackEnd.Service.Implementation
{
    public class MenuService : IMenu
    {
        private readonly UserPermissionDbContext _context;

        public MenuService(UserPermissionDbContext context)
        {
            _context = context;
        }

        public async Task<IQueryable<MenuGetAllDtos>?> GetAllMenusAsync(CancellationToken cancellationToken)
        {
              var menus = await _context.Menu.ToListAsync(cancellationToken);

            if(menus == null)
                return null;
            var menuDtos = menus.Select(m => new MenuGetAllDtos
            {
                MenuId = m.MenuId,
                MenuName = m.MenuName,
            }).AsQueryable();

            return menuDtos;

        }

        public async Task<IQueryable<MenuWithStatusDto>?> GetSelectedMenuwithStatusAsync(int userId, CancellationToken cancellationToken)
        {
            var menuWithgStatus = await _context.Permission
                                                .Include(m=>m.Menu)
                                                .Where(p=>p.UserId == userId)
                                                .ToListAsync(cancellationToken);
            var data = menuWithgStatus.Select(m => new MenuWithStatusDto
            {
                MenuId = m.MenuId,
                IsActive = m.IsActive,
            }).AsQueryable();
            return data;
        }
    }
}
