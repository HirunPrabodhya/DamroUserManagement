﻿using DamroBackEnd.Data;
using DamroBackEnd.Modle;
using DamroBackEnd.Service.DTOS;
using DamroBackEnd.Service.Interface;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DamroBackEnd.Service.Implementation
{
    public class PermissinService : IPermision
    {
        private readonly UserPermissionDbContext _context;

        public PermissinService(UserPermissionDbContext context)
        {
            _context = context;
        }

        public async Task<string?> AddPermissionAsync(PermissionGetDto permisstionGetDto, CancellationToken cancellationToken)
        {
            if (permisstionGetDto == null)
            {
                return "Invalid data";
            }

            try
            {
                foreach (var menu in permisstionGetDto.MenusWithStatus)
                {
                    var permission = new Permission
                    {
                        UserId = permisstionGetDto.UserId,
                        MenuId = menu.MenuId,
                        IsActive = menu.IsActive
                    };

                    await _context.Permission.AddAsync(permission, cancellationToken);
                }

                var count = await _context.SaveChangesAsync(cancellationToken);

                if (count <= 0)
                {
                    return "Data not saved";
                }

                return "Data saved successfully";
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                return $"An error occurred: {ex.Message}";
            }
        }
    }
}
