export interface IMenuSpecificUser{
    menuId:number;
    isActive:string;
}