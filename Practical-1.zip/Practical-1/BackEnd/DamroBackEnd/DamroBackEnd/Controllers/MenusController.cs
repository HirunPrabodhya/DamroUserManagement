﻿using DamroBackEnd.Service.DTOS;
using DamroBackEnd.Service.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DamroBackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenusController : ControllerBase
    {
        private readonly IMenu _menu;

        public MenusController(IMenu menu)
        {
            _menu = menu;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllMenus(CancellationToken cancellationToken)
        {
            var menus = await _menu.GetAllMenusAsync(cancellationToken);
            if (menus == null)
            {
                return NotFound(new
                {
                    message = "menu doles not exist"
                });
            }
            return Ok(menus);
        }
        [HttpGet("{userId:int}")]
        public async Task<IActionResult> GetSelectedMenuwithStatus([FromRoute] int userId,CancellationToken cancellationToken)
        {
            var menus = await _menu.GetSelectedMenuwithStatusAsync(userId, cancellationToken);
            return Ok(menus);
        }
    }
}
