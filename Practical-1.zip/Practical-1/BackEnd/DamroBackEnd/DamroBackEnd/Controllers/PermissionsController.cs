﻿using DamroBackEnd.Service.DTOS;
using DamroBackEnd.Service.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DamroBackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PermissionsController : ControllerBase
    {
        private readonly IPermision _permission;

        public PermissionsController(IPermision permission)
        {
            _permission = permission;
        }

        [HttpPost]
        public async Task<IActionResult> AddPermission([FromBody] PermissionGetDto permisstionGetDto, CancellationToken cancellationToken)
        {
            var message = _permission.AddPermissionAsync(permisstionGetDto,cancellationToken);
            if(message == null)
            {
                return NotFound();
            }
            return Ok(message);
        }
    }
}
