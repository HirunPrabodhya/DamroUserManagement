import { Injectable, inject } from '@angular/core';
import { BASE_URL } from '../../app.config';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { CustomeErrorHandler } from '../../helper/handleError';
import { IMenu } from '../model/menuGetDto';
import { IMenuSpecificUser } from '../model/menusSpecificUser';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private baseUrl:string = inject(BASE_URL);
  private http:HttpClient = inject(HttpClient);

  getAllMenus(): Observable<IMenu[]> {
    return this.http.get<IMenu[]>(`${this.baseUrl}/menus`)
      .pipe(
        catchError(CustomeErrorHandler.handleError)
      );
  }
  getMenuForSecificUser(userId:number):Observable<IMenuSpecificUser[]>{
    return this.http.get<IMenuSpecificUser[]>(`${this.baseUrl}/menus/${userId}`);
  }
  
}
