import { Component, OnInit, inject } from '@angular/core';
import { MenuService } from '../service/menu.service';
import { IMenu } from '../model/menuGetDto';
import { headers } from '../../constant/tableHeader';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../user/service/user.service';
import { IUser } from '../../user/model/UserGetDto';
import { IMenuSpecificUser } from '../model/menusSpecificUser';

@Component({
  selector: 'app-menu-list',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './menu-list.component.html',
  styleUrl: './menu-list.component.css'
})
export class MenuListComponent implements OnInit{
    menuForm!:FormGroup;
   tableHeaders:string[] = headers;
   userList:IUser[] = [];
   menuList:IMenu[] = [];
   private userService:UserService = inject(UserService); 
   private menuService:MenuService = inject(MenuService); 
    
   private fb:FormBuilder = inject(FormBuilder);

  //  menuList:any[] = [
  //   {
  //     menuId:1,
  //     menuName:'menu 1',
  //     isActive:'y'
  //   },
  //   {
  //       menuId:2,
  //       menuName:'menu 2',
  //       isActive:'y'
  //   },
  //   {
  //     menuId:3,
  //     menuName:'menu 3',
  //     isActive:'n'
  //   },
  //   {
  //     menuId:4,
  //     menuName:'menu 4',
  //     isActive:'y'
  //   },
  //   {
  //     menuId:5,
  //     menuName:'menu 5',
  //     isActive:'y'
  //   }
    
  //  ]
    ngOnInit(): void {
      this.menuForm = this.defineFormGroup();
        this.getAllUsers();
        this.getAllMenus();
      this.userId?.valueChanges.subscribe({
        next:value=>this.getMenuForUser(value)
        
      })
    }
    getAllUsers(){
      this.userService.getUserAll()
                      .subscribe({
                        next:(result:IUser[])=> this.userList = result,
                        error:(err:string)=> console.log(err)
                        
                      })
    }
    getAllMenus(){
      this.menuService.getAllMenus()
                      .subscribe({
                        next:(result:IMenu[])=>{
                            this.menuList = result;
                          console.log("IMenu",this.menuList);
                          
                        },
                        error:err=>console.log(err)
                        
                      })
    }
    get userId(){
      return this.menuForm.get('userId');
    }
    get menus(){
      return this.menuForm.get('menus') as FormArray;
    }
    defineFormGroup():FormGroup{
        return this.fb.group({
          userId:[0],
          menus:this.fb.array([])
        });
    }
    onCheckBoxChange(menuId:number,event:Event){
   
      const checkBox = event.target as HTMLInputElement;
      let isActive = (checkBox.checked) ? 'y' : 'n';
      const existingControl = this.checkMenuIdExistInArary(menuId);
      if(existingControl)
            existingControl.patchValue({
              menuId:menuId,
              isActive:isActive
        });
      else
        this.addValuesToArray(menuId,isActive);    
    }
    addValuesToArray(menuId:number, isActive:string){
      this.menus.push(this.fb.group({
        menuId:menuId,
        isActive:isActive
      }));   
    }
    checkMenuIdExistInArary(menuId:number): FormGroup {
       return this.menus.controls.find(control=> control.value.menuId === menuId) as FormGroup
    }
    getMenuForUser(userId:number){
      this.menuService.getMenuForSecificUser(userId)
                      .subscribe({
                        next:(result:IMenuSpecificUser[])=>{
                            this.setValuesToFormArray(result)
                          console.log(result)
                        },
                        error:err=>console.log(err)
                      })
      
    }
    setValuesToFormArray(result:IMenuSpecificUser[]){
      this.menuForm.setControl('menus',this.fb.array(result || []))
      this.menuList.forEach(menu=>{
        const userMenu = result.find(r=> r.menuId === menu.menuId);
        menu.isActive = userMenu ?userMenu.isActive : 'n';
      })
    }

    buildFormGroup(){
      return this.fb.group({
          menuId:[0],
          isActive:'n'
      })
    }
    onSavePermission(){
      if(this.userId?.value === 0 || this.menuForm.invalid)
          alert("form is invalid")
       else 
      console.log(this.menuForm.value);
      
    }
    
    
}
