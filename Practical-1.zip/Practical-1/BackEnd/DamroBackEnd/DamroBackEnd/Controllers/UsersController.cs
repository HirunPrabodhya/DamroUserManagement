﻿using DamroBackEnd.Service.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DamroBackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUser _user;
        public UsersController(IUser user)
        {
            _user = user;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllUsers(CancellationToken cancellationToken)
        {
            var users = await _user.GetAllUsersAsync(cancellationToken);
            if(users == null)
            {
                return NotFound(new
                {
                    message = "user does not exist"
                });
            }

            return Ok(users); 
        }
       
    }
}
